<div id="<?php print $block->region .'-'. $block->module .'-'. $block->delta; ?>">
	<div class="art-article content">
		<?php print $block->content ?>
	</div>
</div>